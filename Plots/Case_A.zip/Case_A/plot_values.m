load('psi.mat', 'ans')
f1 = figure
hold on
grid on
subplot(2, 1, 1);
plot(u_hat)